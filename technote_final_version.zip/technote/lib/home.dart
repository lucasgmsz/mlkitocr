import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class HomePage extends StatefulWidget
{
  @override
  State<StatefulWidget> createState() {
    return HomePageState();
  }
}

class HomePageState extends State<HomePage>
{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Anotações"),
        backgroundColor: Colors.yellow[800],
      ),
      body: StreamBuilder(
        stream: Firestore.instance.collection('notas').orderBy('data', descending: true).snapshots(),
        builder: (context, snapshot) {

          if(snapshot.connectionState == ConnectionState.waiting)
                return Center(child: CircularProgressIndicator());

          return ListView.builder(
            itemCount: snapshot.data.documents.length, // snapshot.data = dynamic
            itemBuilder: (context, indice) {
              DocumentSnapshot document = snapshot.data.documents[indice];
              return Card(
                child: InkWell(
                  onTap: () {
                    Navigator.of(context).pushNamed('/edit', arguments: document.documentID);
                  },
                  child: Container(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Container(
                              child: Text(
                                document.data['titulo'],
                                textDirection: TextDirection.ltr,
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 17.0
                                ),
                              )
                            ),
                            Container(
                              child: Text(
                                document.data['data'],
                                textDirection: TextDirection.rtl,
                                style: TextStyle(
                                  fontSize: 12.0
                                ),
                              ),
                            )
                          ],
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Container(
                              margin: EdgeInsets.only(top: 6.0),
                              height: 50.0,
                              child: Text(
                                document.data['descricao'],
                                textDirection: TextDirection.ltr,
                                textAlign: TextAlign.start,
                              ),
                            )
                          ],
                        )
                      ],
                    ),
                  )
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
       child: Icon(Icons.note_add),
       backgroundColor: Colors.yellow[800],
       onPressed: () {
          Navigator.of(context).pushNamed('/create');
        },
      )
    );
  }
}
