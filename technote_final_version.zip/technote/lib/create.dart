import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_ml_vision/firebase_ml_vision.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class CreatePage extends StatefulWidget {
  @override
  _CreatePageState createState() => _CreatePageState();
}

class _CreatePageState extends State<CreatePage> {

  GlobalKey<FormState> _formKey = new GlobalKey<FormState>();

  File pickedImage;
  bool isImageLoaded = false;
  String titulo;
  String descricao;
  String textoReconhecido;

  TextEditingController tituloCtrl = TextEditingController();
  TextEditingController descricaoCtrl = TextEditingController();

  Future pickImageFromCamera() async {
    var tempStore = await ImagePicker.pickImage(source: ImageSource.camera);

    setState(() {
      pickedImage = tempStore;
      isImageLoaded = true;
    });

    readText();
  }

  Future pickImageFromGallery() async {
    var tempStore = await ImagePicker.pickImage(source: ImageSource.gallery);

    setState(() {
      pickedImage = tempStore;
      isImageLoaded = true;
    });

    readText();
  }

  Future readText() async {GlobalKey<FormState> _formKey = new GlobalKey<FormState>();
    FirebaseVisionImage ourImage = FirebaseVisionImage.fromFile(pickedImage);
    TextRecognizer recognizeText = FirebaseVision.instance.textRecognizer();
    VisionText readText = await recognizeText.processImage(ourImage);

    // for (TextBlock block in readText.blocks) {
    //   for (TextLine line in block.lines) {
    //     for (TextElement word in line.elements) {
    //       _texto = word.text;
    //     }
    //   }
    // }

    setState(() {
      descricaoCtrl.text += '\n' + readText.text;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Nova nota"),
        backgroundColor: Colors.yellow[800],
        actions: <Widget>[
          IconButton(icon: new Icon(Icons.image), onPressed: pickImageFromGallery),
          IconButton(icon: new Icon(Icons.photo_camera), onPressed: pickImageFromCamera)
        ],
      ),
      
      body: Form(
        key: _formKey,
        autovalidate: false,
        child: ListView( // scroll
          children: <Widget>[

            SizedBox(height: 10.0,),

            TextFormField(
              keyboardType: TextInputType.text,
              decoration: InputDecoration(
                hintText: "Título",
              ),
              validator: (texto) {
                if(texto.length == 0)
                  return "Campo título obrigatório";
              },
              onSaved: (texto) {
                this.titulo = texto;
              },
            ),

            SizedBox(height: 10.0,),
      
            TextFormField(
              controller: descricaoCtrl,
              keyboardType: TextInputType.text,
              decoration: InputDecoration(
                hintText: "Comece a digitar...",
              ),
              maxLines: 28,
              onSaved: (texto) {
                this.descricao = texto;
              },
            ),

          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
       child: Icon(Icons.check),
       backgroundColor: Colors.yellow[800],
       onPressed: salvar,
      )
    );
  }

  void salvar() {
    FormState _form = _formKey.currentState;

    if(_form.validate())
    { 
      _form.save();

      var dados = Map<String, dynamic>();
      dados["titulo"] = this.titulo;
      dados["descricao"] = this.descricao;
      String data = DateFormat('dd/MM/yyyy').format(DateTime.now());
      dados["data"] = data;

      Firestore.instance.collection("notas").add(dados);

      Navigator.of(context).pop();
    }
  }
}