import 'package:flutter/material.dart';
import 'package:technote/home.dart';
import 'package:technote/create.dart';
import 'package:technote/edit.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: '/',
      routes: {
        //'/' : (context) => LoginPage(),
        //'/signup' : (context) => SignupPage(),
        '/' : (context) => HomePage(),
        '/create' : (context) => CreatePage(),
        '/edit' : (context) => EditPage(),
      }
      // home: HomePage()
    );
  }

}