import 'package:flutter/material.dart';
//import 'package:technote/auth.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:technote/home.dart';
import 'package:technote/signup.dart';

class LoginPage extends StatefulWidget
{
  @override
  State<StatefulWidget> createState() {
    return LoginPageState();
  }
}

class LoginPageState extends State<LoginPage>
{
  String _email, _senha;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //backgroundColor: Colors.yellow[50],
      // appBar: AppBar(
      //   title: Text("Entrar"),
      //   backgroundColor: Colors.yellow[800],
      // ),
      body: Form(
        key: _formKey,
        child: Center(
          child: ListView(
            shrinkWrap: true,
            padding: EdgeInsets.only(left: 24.0, right: 24.0),
            children: <Widget>[
              Hero(
                tag: '',
                child: CircleAvatar(
                  backgroundColor: Colors.transparent,
                  radius: 48.0,
                  child: Image.asset('assets/logo.png'),
                ),
              ),
              SizedBox(height: 8.0,),
              Text(
                'Technote', 
                style: TextStyle(
                  color: Colors.black87, 
                  //fontFamily: 'Nunito', 
                  fontSize: 22.0
                ),
                textAlign: TextAlign.center,
              ),
              
              SizedBox(height: 48.0,),
              Text(
                'Conectar-se', 
                style: TextStyle(
                  color: Colors.black87, 
                  fontFamily: 'Nunito', 
                  fontSize: 26.0
                ),
                textAlign: TextAlign.center,
              ),
              
              SizedBox(height: 48.0,),
              TextFormField(
                keyboardType: TextInputType.emailAddress,
                validator: (input) {
                  if(input.isEmpty) {
                    return 'Digite seu e-mail!';
                  }
                },
                onSaved: (input) => _email = input,
                decoration: InputDecoration(
                  //labelText: 'E-mail',
                  hintText: 'E-mail',
                  contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(32.0)
                  )
                ),
              ),
              SizedBox(height: 8.0,),
              TextFormField(
                validator: (input) {
                  if(input.isEmpty) {
                    return 'Digite sua senha!';
                  }
                },
                onSaved: (input) => _senha = input,
                decoration: InputDecoration(
                  //labelText: 'Senha',
                  hintText: 'Senha',
                  contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(32.0)
                  )
                ),
                obscureText: true,
              ),
              SizedBox(height: 24.0,),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 16.0),
                child: Material(
                  borderRadius: BorderRadius.circular(30.0),
                  shadowColor: Colors.yellow[800],
                  //elevation: 5.0,
                  child: MaterialButton(
                    minWidth: 200.0,
                    height: 42.0,
                    onPressed: signIn,
                    color: Colors.yellow[800],
                    child: Text('Entrar', style: TextStyle(color: Colors.white, fontFamily: 'Nunito', fontSize: 16.0)),
                  ),
                ),
              ),
              FlatButton( 
                onPressed: navigateToSignUp,
                child: Text('Não tem uma conta?', style: TextStyle(color: Colors.black54),),
              )
            ]
          ),
        ),
      ),
    );
  }

  Future<void> signIn() async {
    final formState = _formKey.currentState;
    if(formState.validate()){ 
      formState.save();
      try{
        FirebaseUser user = await FirebaseAuth.instance.signInWithEmailAndPassword(email: _email, password: _senha);
        print('Uid: ' + user.uid);
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => HomePage(user: user)));
      } catch(e) {
        print(e.message);
      }
    }
  }

  void navigateToSignUp() {
    Navigator.push(context, MaterialPageRoute(builder: (context) => SignUpPage(), fullscreenDialog: true));
  }
}
