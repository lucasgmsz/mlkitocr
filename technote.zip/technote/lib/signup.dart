import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:technote/login.dart';

class SignUpPage extends StatefulWidget
{
  @override
  State<StatefulWidget> createState() {
    return SignUpPageState();
  }
}

class SignUpPageState extends State<SignUpPage>
{
  String _email, _senha;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: Colors.yellow[50],
      appBar: AppBar(
        title: Text("Criar conta"),
        backgroundColor: Colors.yellow[800],
      ),
      body: Form(
        key: _formKey,
        child: Center(
          child: ListView(
            shrinkWrap: true,
            padding: EdgeInsets.only(left: 24.0, right: 24.0),
            children: <Widget>[
              Text(
                'Nova conta', 
                style: TextStyle(
                  color: Colors.black87, 
                  fontFamily: 'Nunito', 
                  fontSize: 26.0
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 48.0,),
              TextFormField(
                keyboardType: TextInputType.emailAddress,
                validator: (input) {
                  if(input.isEmpty) {
                    return 'Digite um e-mail!';
                  }
                },
                onSaved: (input) => _email = input,
                decoration: InputDecoration(
                    //labelText: 'E-mail',
                    hintText: 'E-mail',
                    contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(32.0)
                    )
                  ),
              ),
              SizedBox(height: 8.0,),
              TextFormField(
                validator: (input) {
                  if(input.isEmpty) {
                    return 'Digite uma senha!';
                  }
                  if(input.length < 6) {
                    return 'Sua senha deve conter no mínimo 6 caracteres!';
                  }
                },
                onSaved: (input) => _senha = input,
                decoration: InputDecoration(
                    //labelText: 'Senha',
                    hintText: 'Senha',
                    contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(32.0)
                    )
                  ),
                obscureText: true,
              ),
              SizedBox(height: 24.0,),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 16.0),
                child: Material(
                  borderRadius: BorderRadius.circular(30.0),
                  shadowColor: Colors.yellow[800],
                  //elevation: 5.0,
                  child: MaterialButton(
                    minWidth: 200.0,
                    height: 42.0,
                    onPressed: signUp,
                    color: Colors.yellow[800],
                    child: Text('Criar conta', style: TextStyle(color: Colors.white, fontFamily: 'Nunito', fontSize: 16.0)),
                  ),
                ),
              ),
              FlatButton( 
                onPressed: navigateToLogin,
                child: Text('Já possui uma conta?', style: TextStyle(color: Colors.black54),),
              )
            ]
          ),
        ),
      ),
    );
  }

  Future<void> signUp() async {
    if(_formKey.currentState.validate()){
      _formKey.currentState.save();
      try{
        FirebaseUser user = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: _email, password: _senha);
        //user.sendEmailVerification();
        Navigator.of(context).pop();
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => LoginPage()));
      } catch(e) {
        print(e.message);
      }
    }
  }

  void navigateToLogin() {
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => LoginPage(), fullscreenDialog: true));
  }
}
