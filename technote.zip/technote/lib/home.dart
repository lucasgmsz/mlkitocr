import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:technote/login.dart';
import 'package:url_launcher/url_launcher.dart';

var usuario_id;

class HomePage extends StatefulWidget
{
  final FirebaseUser user;

  const HomePage({
    Key key, 
    this.user
  }) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    usuario_id = user.uid;
    return HomePageState();
  }
}

class HomePageState extends State<HomePage>
{
  HomePage homePage = new HomePage();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Anotações"),
        backgroundColor: Colors.yellow[800],
        actions: <Widget>[
          PopupMenuButton(
            itemBuilder: (BuildContext context) {
              return [
                PopupMenuItem(
                  child: FlatButton(
                    onPressed: () => launch('https://technoteapp.wordpress.com/'),
                    child: Text('Política de privacidade', textAlign: TextAlign.start,),
                  ),
                ),
                PopupMenuItem(
                  child: FlatButton(
                    onPressed: logout,
                    child: Text('Sair', textAlign: TextAlign.start),
                  ),
                ),
              ];
            },
          )
          //IconButton(icon: Icon(Icons.power_settings_new), color: Colors.white, onPressed: logout,)
        ],
      ),
      body: StreamBuilder(
        stream: Firestore.instance.collection('notas').where('usuario_id', isEqualTo: usuario_id).orderBy('timestamp', descending: true).snapshots(),
        builder: (context, snapshot) {

          if(snapshot.connectionState == ConnectionState.waiting)
                return Center(child: CircularProgressIndicator());

          return ListView.builder(
            itemCount: snapshot.data.documents.length, // snapshot.data = dynamic
            itemBuilder: (context, indice) {
              DocumentSnapshot document = snapshot.data.documents[indice];
              return Card(
                child: InkWell(
                  onTap: () {
                    Navigator.of(context).pushNamed('/edit', arguments: document.documentID);
                  },
                  child: Container(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Container(
                              child: Text(
                                //usuario_id,
                                //homePage.ler_usuario_id(),
                                document.data['titulo'],
                                textDirection: TextDirection.ltr,
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 17.0
                                ),
                              )
                            ),
                            Container(
                              child: Text(
                                document.data['data'],
                                textDirection: TextDirection.rtl,
                                style: TextStyle(
                                  fontSize: 12.0
                                ),
                              ),
                            )
                          ],
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Container(
                              margin: EdgeInsets.only(top: 6.0),
                              height: 50.0,
                              child: Text(
                                document.data['descricao'],
                                textDirection: TextDirection.ltr,
                                textAlign: TextAlign.start,
                              ),
                            )
                          ],
                        )
                      ],
                    ),
                  )
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
       child: Icon(Icons.note_add),
       backgroundColor: Colors.yellow[800],
       onPressed: () {
          Navigator.of(context).pushNamed('/create');
        },
      )
    );
  }

  void logout() {
    FirebaseAuth.instance.signOut();
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => LoginPage()));
  }
}
